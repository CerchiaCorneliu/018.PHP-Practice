document.getElementById("special").onclick = function() {
	alert("You clicked me!");
}